/*
 * UART0.h
 *
 * Created: 30.07.2011 12:48:17
 *  Author: Christian
 */ 


#ifndef UART0_H_
#define UART0_H_

#define BAUD	57600
#define DEBUG	0

void UART0_init();
void UART0_put_char(char data);
void UART0_print(char *buffer);
void UART0_put_hex(unsigned char data);
void UART0_put_dec(unsigned int data);
void UART0_ELV_8(unsigned char data);
void UART0_ELV_4(unsigned char data);
uint8_t UART0_get_char(void);




#endif /* UART0_H_ */