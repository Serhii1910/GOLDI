// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#ifndef _USERDESIGN_H
    #define _USERDESIGN_H

    #include "../Main.h"
    extern void StateMachineInit(void);                                                     // This function initializes the state machine
    extern void StateMachineUpdate(void);                                                   // This function updated the state machine

// ######################################################################################
// #  Add a new state for state machine here                                            #
// ######################################################################################
    typedef enum
    {
       Init,                                                                               // Z0 - init state
       DriveXMinus,                                                                        // Z1 - drive to left
       DriveXPlus                                                                          // Z2 - drive to right
    } AutomatStates_t;
    
#endif 